<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
 <style>
            table {
            font-family: arial, sans-serif;
            font-size:small;
            border-collapse: collapse;
            width: 50%;
            }

            td, th {
           
            text-align: center;
            padding: 8px;
            }
	
            tr:nth-child(even){
	background-color:#CCCCCC;
}

            input[type=text]{
                width: 25%;
                padding: 12px 20px;
                margin: 8px 0;
                display: inline-block;
                border: 1px solid #ccc;
                border-radius: 4px;
                box-sizing: border-box;
            }
            img{float:center;}
			
			button {
			  background-color: #ff6600;
			  border: 2px;
			  border-radius: 4px;
			  color: white;
			  padding: 12px 20px;
			  text-align: center;
			  text-decoration: none;
			  display: inline-block;
			  font-size: 16px;
			  margin: 8px 0px;
			  cursor: pointer;
			}
			
        </style>
</head>
<body>
<form action="" method=post>
<div align="center">
            <div>
<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAK8AAAB6CAMAAAD+v/PbAAABZVBMVEX////ofmrod1/76+nneWTxsaYAAAD5jXrofGj++/r99fPqjXzvpZn76OQnI2nnd2IkH2Dw8PD1ysKmpaXh4eEgHFrn5+dBLYDW1tbKyckiQoG3traura329vYWS4zR0NDBwMCcm5uGhYUlLmokN3USVJQCg8HtnpDmcFlubGxVUlNlY2MyLi9cWlp6eHglKF4SYqMBmdQAquJAPT5KR0gGcLAEeroCjsv53dgaFBY4xfB2R2ldP2vIbmbzvbTrlYYjHyDc6PC4zdulprSNnrWDt9KRxuC33e/M5vPr+f+jyt5ZkrZUoMVPhatuk7Ncd5tBWYEaTnyRrsZUZoY5QGxfX4AxMl+UlKYjlcQ2X5A0QXd9hKZubo8AQIkAAE28vcoMDEuRl8RQUH8AJHKylZpCUY5ycqpfYJeGhbpxY6NMR41UR5ilZGoiAE0wKYaJ1PIvFmqYWnoOAFy8dXNyVHZPNGqEUGMhnqvzAAAL/0lEQVR4nO2cj3fbRBLH17Gjs5yfihRViiRLq8RN9LMudoIFNBaFlkILhQLlKMdxpdfS0gK5A/r338yu5NixXOyjkXPv/H2vrb1azX40Ozs76z6bkIUWmoNE6d13P/xw3hTTyr7+3vs3bty4+cGtW/8DzNc/un3n49u3b35y98bN2++/p8yb59X68KNPP/vsl5ufvH/v0/uff/PF9vaX74nzZnqFbn382ZW7d+/eu//5F1e4tu9/Jc2baqJu3fnr11cePNh9sMuUIX+lzptrgpT7u3uAuZcpQ97+5t15gxVL+ts2g93JxJDRwV/o80Yr1PVvERdAm0yMOIuKi5glpDbzbbPZyoTI3MV//27ecAX6rt1E3FarDTqEP4yYAf/joTVvunG1D5uc9vDwCHR4yIgR+Mr3Dy/ekpMeHbaBl9FeRgEyEDd3Hv+w+/Thwz9rXtxafr3653qrjbgI+ybTZfRxq/n4yQ9Pnj6d3tAE3uWl2uvU0m97Oxz3zTevciFwu93c+eHp4ycP6tMa+ssk3lrldar2ADJDjvsGKAcGBz979vjZtfp0duol8oJ7B7iMmAE3d56BLiBvq/UA3Mtx38qAmYN/fP78+UXjrb+z02q3tpsA/MZbTJmDOe+lqe2UxfsCwqF9dLj7009Xc14AhoBofQu8P0/p3tJ4K5VHGL5XW9vbP91B3DutIwC+3G5eQj2f1kppvPXtZvvo8tHeNujGL7/c/Prk5Crwthjuz/+6cLyVF3uwne0C7ebm3Q8Ad/2kfXT18uGPjPfaxeOt7O0w5wLv97fu/Xt9ff3SCa435J3avWXyvvi2ucdwN3fvXee8rebhDvJO7d4SeevXvszCARz8ZJ3xHp1gOPz8YgYr5fm3/utOhru5uc508iN699H00VAqL3h4M+PluOvtvcOTS+u/TR8N5fIC8O/D7oUMsXMCuNPuFaXzAvDLK+sDXFDr9xdLs1kolRf35bd/33zEYR+tvzObc+fAW6nXf3358u13QG+/fFmZkXZm3qzILzTF2ut/0AMA68B8DQT/nFosUtHDzMRbX8nOUBtFNNC+Uu/zDquT7l5BCG5mddhikVb+NG+/2kCJB+PXNrYajR706LEea/vjzqmvio1eH9vhBagH7PV+Y6LEAhszxsPKFr9acPFAJKS3VNno8R5bY8u+vgKXjjk467LGeIuHZyqcpJl4a9lpulpAQ0hjv1bZOOafP/fGbq8h2vFGubz7VX557Ar6tcGeYo11aIzfD8/aY+E7xFup9PsroNNWZhqb+v0CgFnzw8Yxv9w76+CNBsQAOu8gD4gz99crJI+SEd46E/oi42UpJG/8s7y1ZT7djaXxdpEb7Dc4TX90PJz56mp9jPfURMb76pQ8Iy9bNHj5TGwdQBRUedY4qGYGRpNeDZZqj7OUyAtpqygg6ivVQdLIe2yN3lgDm8cbpfPmK646MtjGFoTJwJ88ZKr7wxaQJr+nTN48wYpbI9MNjb28YYlniNEkjVGSz0m5vAUJtr4Ka2wwem0/C5kRniGTpfKyUCWDtc60BCHbOH17kNkYCoga5MHq6eOVyHuaYE8DApPG8uk4+YobajqACejlVUe5vLVVnmB7p3zLw+GQbQ1keE1iUhZP35XKmydYcpz3YKl1pPjLVtygwML03BgUdSXzDhJsvnwwxa0OD5OXAqcpuDr0eGXz1rMEu9bPNggoZMT+cHcs1pgyohrmlLHHKYt3EBB5l62srh3S1khAYM5eO63xy+YdTDeL2dp+Y6xUzcdeY81wLCFkqPwpmzdPsA2eYLGuPVuMrWQrjr3D9CyObC8l8y4NJVh+zBkbJKuT+SKDHltDPUrnzddTLzvRjHfOB8ckVlsdDYfyeSs1vmUwiuWzlQJ/omwXhCt4Jhkp58rnzVfcMiS3anaKPPNE+cHpgB2qlwvuLpM3T7CsGFvbH+9b28/OnRuYnkfCYQ68bAmxgKj1ij5rQMN8TcKZ4jjPfHPkzQOih6ltq+jjqbxOXsPUtlwvuLlU3uwUTPbHxs17ZCuuenz2aDSXeMgTbKPgswiurCwSG2O79Tx4c+tAXPSxUSU7JHGdsTUP3kGCJdWJhX22J4/v1vOIhzzBFmcHFDvko47PmJoPbzbdYuFqY6ZXeI+xj/7mwstOQWT4mDOmAx4Q4x+tcrJqubwbq1uo1cn2633WY/x/D3j78UpR77Ofa7423kp9A/XKbXtCj+J23lr4XyOvhXcuWvCerxa856sF7/lqwXu+WvCerxa856sF7/lqMu/B0oXUBF7SqF5QTeBdaKGFFvpj6aZCiK2LhBj4RVbVcGRRNBwiGYYpq0SSTdmxHNkwZEeEq6Zhwg2SY6pEMfB+Rcavk8pEhY4acbBNdYgGt2omXnYkQkyQjNYd/DKyCsZM7GeaBtysmtosvIYgE+LC7aIQw1tKdUqsyCOKHzsp/CMEjk5iwdHl0CCa7zmO7ykWFRwSM16tG0tESomeuIZCvAQg7ZjIgm11HUIsGtqA6QgdB6iUDg5hC65OuzCqEBldKtqpMQuvGrpEdcFHhu/D324A/rCCmKgBJV0BeCl0cgVodLsaNhJNcAE8tl3+NVKaaITqRA/RgXESgnNjYgq26+DTRCGjCQPWNRSwLYUrXiKRJLZi19LCmb6gbNGuZhoQDl2G5go++NdDXldOdODtejK4k/nFlAIKkIKHlJ1sGp3UJB2IqyQKdOLZaUdXgDf10ZXEpjTAGEgjdA2l6EsNHgnGUUjqGV2Ys3CmeEAMjC3Nh5m1iGimiSyif70gBH5FcC2J+Rc7qlHOqwZB9k1+8LsJk6uHjmSRQLUE33SBN0mAU3UdKiBOgv6VqdLtDHg1knZwhFl5VS+kMHSXyi4GH5s7Fg9mJFjD8RBHCvCK+AiESHGc//IAFQR4qXdwWsGZqpAAb6L7CTxt13RD9ojIS10zgK6MNxZEkgYUbpoxHmBCYe0QKQTrCSWwxjuGBZOpRFTtpAgnqWDdsgyIRMWnkpSAe4nkRTmvEvkW+tdQVBKpPL5hvRlJLOI6xpmHpQULBAM+8YkNvBSdKsRK4lo64s8izYV7KUypRGNF9jF+Y2oprkzcSFP9wHclGkR+rGDXKMKVzfoOftmBYkbT4YpBXAxWh8Li1UgcqEhoRJAhfJgSA7kCj9g+GMN+EfazbW+m/LDQQv93+u9+IMEavW2WX2JRI5MoLixcUXaIHlPPcgPP80wiwyt4EciSjAlAdyX2VieR57n8p1O0gJqeKUJXL3CxwYQenmsZgRdBpoBGtIPpLsCt3sEekNh1T5YDeON4LN/SwKDslRPELmzzOqQRyZvEi9uA5qcK8BqqZ1q6JUHmgg3KDSVJDXwFXnUAT/eJZEMmtmBTs7hDpNDlyRh2LknifosFSbJooEkiiVJV0jTIuirLukqQgFdkE7KubEH1oxOD5VsqKJZEuzbshIYkKcALyd81X8WruClsYKajddkWDx6Ev1wfELwIZs7tIm+EWy9sakRws1v9VGSbsEqFwYyy/Y96WDoKetYisV1YcUPYeWVH8j0cpBsSo2Ozqo5TSJ6fWYHHjyeGCPOvqXcE0bCJnAiySESf8QZjvAovcsIONxeG+LcsKDTtdNwhXjnphGogZC1JGqbIazqRIMm6yp/XFzivmbLiOHWN0MTHhz96V5hcSDBe2XLS0LSRCrpmvPi4EeNl8eBhJSQP+5fz0lQZ8m/M/IvP4wnWqH9lye4KVFdTdn834byASVgBoHfQeBrwEHklrw5lDvhEE6He7gJvl/F2YRyf8UJ0Q/mOc8f8G+dzn+DG7LtQZA5+uojz4ow7WP4TMYvfgGhUJU6Y2JaLa9EGasarRlhgOqljxV1oD6MpeA0sy2hHU6hhuBIRO4w3hHG6yKv7rmNgSNrIKwqR43DXQbbQXU9hJeGAVwRe3zSh9OwYuqMNeHVMKiasOaindR3qPiKH1ICDU9fUjQjr0MB19DD+A15Jtolm4/imJBlURk+ZDsHjHJYoBl6BWpuy85ZhQ3TD8czIEoQsyybGijyIBwcGFm1Zxv5gDYo8XQYTkCtVHTthdxVvg0YNumloHQ+GaN6EG2wcT54lIy+00EKvUf8BtEnEONtyYHsAAAAASUVORK5CYII=">
 <h3 style="font-size:25px;color:#ff6600;">
                 Vasireddy Venkatadri Institute of Technology(Autonomous)<br>II B.Tech I Semester (R20) Regular Examinations, FEB 2023 Results</h1>
            </div>
           <input type="text" placeholder="Enter your rollno here to view result..." name="rollno" id="rno" maxlength="10" size="17" autofocus/> 

<input style="background-color:#ff6600;border-radius:10px;;width:100px;height:40px;" type="submit" name='submit' value="print"  ><br>

			
            <!--<div id="resdata"></div>
            <h3>Note: Last date for Recounting/Revaluation/Challenge by Revaluation is 20-04-2023</h3>
            <b style="color:red">Important!! The data provided on this site is purely for informational purpose.</b><br>-->
			
    
<?php  
  $servername = "localhost";
  $username = "root";
  $password = "";
  $databasename = "project";
  $conn = new mysqli($servername,
    $username, $password, $databasename);
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }
if(isset($_POST['submit'])){
$rno=strtoupper($_POST['rollno']);
if(strpos($rno,"1A05")!==false && substr($rno,0,2)=="21"){

  
  $query = "SELECT * FROM `21results_cse` where rollno='$rno'";
  
  $result = $conn->query($query);
  if ($result->num_rows > 0) 
    {

        while($row = $result->fetch_assoc())
        {
?>

<table >
<tr>
<th>HallTicketNo</th>
<td><?php echo $row["rollno"]?></td>
</tr>
<tr>
<th>Name</th>
<td><?php echo $row["name"]?></td>
</tr>
</table>
<br>
<table>
<tr>
<th>Subject Code</th>
<th>Subject</th>
<th>Grade</th>
<th>Credits</th>
</tr>
<tr>
<td>20SH3T01</td>
<td>MATHEMATICS III</td>
<td><?php echo $row["m3_g"]?></td>
<td><?php echo $row["m3_c"]?></td>
</tr>
<tr>
<td>20CS3T01</td>
<td>MATHEMATICAL FOUNDATIONS OF COMPUTER SCIENCE</td>
<td><?php echo $row["mfcs_g"]?></td>
<td><?php echo $row["mfcs_c"]?></td>
</tr>
<tr>
<td>20CS3T02</td>
<td>DATA STRUCTURES</td>
<td><?php echo $row["ds_g"]?></td>
<td><?php echo $row["ds_c"]?></td>
</tr>
<tr>
<td>20CS3T03</td>
<td>JAVA PROGRAMMING</td>
<td><?php echo $row["jp_g"]?></td>
<td><?php echo $row["jp_c"]?></td>
</tr>
<tr>
<td>20CS3T04</td>
<td>SOFTWARE ENGINEERING</td>
<td><?php echo $row["se_g"]?></td>
<td><?php echo $row["se_c"]?></td>
</tr>
<tr>
<td>20CS3L01</td>
<td>DATA STRUCURES LAB</td>
<td><?php echo $row["dslab_g"]?></td>
<td><?php echo $row["dslab_c"]?></td>
</tr>
<tr>
<td>20CS3L02</td>
<td>JAVA PROGRAMMING LAB </td>
<td><?php echo $row["jplab_g"]?></td>
<td><?php echo $row["jplab_c"]?></td>
</tr>
<tr>
<td>20CS3L03</td>
<td>SOFTWARE ENGINEERING LAB</td>
<td><?php echo $row["selab_g"]?></td>
<td><?php echo $row["selab_c"]?></td>
</tr>
<tr>
<td>20CS3C01</td>
<td>SOC(ADVANCED PYTHON PROGRAMMING)</td>
<td><?php echo $row["soc_ap_g"]?></td>
<td><?php echo $row["soc_ap_c"]?></td>
</tr>
<tr>
<td>20SH3N01</td>
<td>ESSENCE OF INDIAN TRADITIONAL KNOWLEDGE</td>
<td><?php echo $row["eitk"]?></td>
</tr>
<tr>
<td>20SH3N01</td>
<td>LIFE SKILLS III</td>
<td><?php echo $row["ls3"]?></td>
</tr>
<tr>
</tr>
<tr>
</tr>
<tr>
<td></td>
<td>Pass/Fail</td>
<td><?php echo $row["res"]?></td>
</tr>
<tr>
<td></td>
<td>SGPA</td>
<td><?php echo $row["sgpa"]?></td>
</tr>
 <?php   
} 
}
     }
elseif(strpos($rno,"1A12")!==false && substr($rno,0,2)=="21"){

  $rno=strtoupper($_POST['rollno']);
  $query = "SELECT * FROM `21results_inf` where rollno='$rno'";
  
  $result = $conn->query($query);
  if ($result->num_rows > 0) 
    {

        while($row = $result->fetch_assoc())
        {
?>

<table id="t1">
<tr>
<th>HallTicketNo</th>
<td><?php echo $row["rollno"]?></td>
</tr>
<tr>
<th>Name</th>
<td><?php echo $row["name"]?></td>
</tr>
</table>
<br>
<table id="t2">
<tr>
<th>Subject Code</th>
<th>Subject</th>
<th>Grade</th>
<th>Credits</th>
</tr>
<tr>
<td>20SH3T01</td>
<td>MATHEMATICS III</td>
<td><?php echo $row["m3_g"]?></td>
<td><?php echo $row["m3_c"]?></td>
</tr>
<tr>
<td>20IT3T01</td>
<td>MATHEMATICAL FOUNDATIONS OF COMPUTER SCIENCE</td>
<td><?php echo $row["mfcs_g"]?></td>
<td><?php echo $row["mfcs_c"]?></td>
</tr>
<tr>
<td>20IT3T02</td>
<td>DATA STUCTURES</td>
<td><?php echo $row["ds_g"]?></td>
<td><?php echo $row["ds_c"]?></td>
</tr>
<tr>
<td>20IT3T03</td>
<td>JAVA PROGRAMMING</td>
<td><?php echo $row["jp_g"]?></td>
<td><?php echo $row["jp_c"]?></td>
</tr>
<tr>
<td>20IT3T04</td>
<td>SOFTWARE ENGINEERING</td>
<td><?php echo $row["se_g"]?></td>
<td><?php echo $row["se_c"]?></td>
</tr>
<tr>
<td>20IT3L01</td>
<td>DATA STRUCTURES LAB</td>
<td><?php echo $row["dslab_g"]?></td>
<td><?php echo $row["dslab_c"]?></td>
</tr>
<tr>
<td>20CS3L02</td>
<td>JAVA PROGRAMMING LAB</td>
<td><?php echo $row["jplab_g"]?></td>
<td><?php echo $row["jplab_c"]?></td>
</tr>
<tr>
<td>20IT3L03</td>
<td>UML LAB</td>
<td><?php echo $row["umllab_g"]?></td>
<td><?php echo $row["umllab_c"]?></td>
</tr>
<tr>
<td>20IT3C01</td>
<td>SOC(ADVANCED PYTHON PROGRAMMING)</td>
<td><?php echo $row["soc_ap_g"]?></td>
<td><?php echo $row["soc_ap_c"]?></td>
</tr>
<tr>
<td>20SH3N01</td>
<td>ESSENCE OF INDIAN TRADITIONAL KNOWLEDGE</td>
<td><?php echo $row["eitk"]?></td>
</tr>
<tr>
<td>20SH3N01</td>
<td>LIFE SKILLS III</td>
<td><?php echo $row["ls3"]?></td>
</tr>
<tr>
</tr>
<tr>
</tr>
<tr>
<td></td>
<td>Pass/Fail</td>
<td><?php echo $row["res"]?></td>
</tr>
<tr>
<td></td>
<td>SGPA</td>
<td><?php echo $row["sgpa"]?></td>
</tr>





 <?php   
} 
}
     }
elseif(strpos($rno,"1A04")!==false && substr($rno,0,2)=="21"){

 
  $query = "SELECT * FROM `21results_ece` where rollno='$rno'";
  
  $result = $conn->query($query);
  if ($result->num_rows > 0) 
    {

        while($row = $result->fetch_assoc())
        {
?>

<table id="t1">
<tr>
<th>HallTicketNo</th>
<td><?php echo $row["rollno"]?></td>
</tr>
<tr>
<th>Name</th>
<td><?php echo $row["name"]?></td>
</tr>
</table>
<br>
<table id="t2">
<tr>
<th>Subject Code</th>
<th>Subject</th>
<th>Grade</th>
<th>Credits</th>
</tr>
<tr>
<td>20SH3T01</td>
<td>MATHEMATICS III</td>
<td><?php echo $row["m3_g"]?></td>
<td><?php echo $row["m3_c"]?></td>
</tr>
<tr>
<td>20EC3T01</td>
<td>ELECTRONIC DEVICES AND CIRCUITS</td>
<td><?php echo $row["edac_g"]?></td>
<td><?php echo $row["edac_c"]?></td>
</tr>
<tr>
<td>20IT3T02</td>
<td>SIGNALS AND SYSTEMS</td>
<td><?php echo $row["sas_g"]?></td>
<td><?php echo $row["sas_c"]?></td>
</tr>
<tr>
<td>20IT3T03</td>
<td>DIGITAL CIRCUITS AND LOGIC DESIGN</td>
<td><?php echo $row["dcld_g"]?></td>
<td><?php echo $row["dcld_c"]?></td>
</tr>
<tr>
<td>20SH3T04</td>
<td>RANDOM VARIABLES AND STOCHASTIC PROCESSES</td>
<td><?php echo $row["rvasp_g"]?></td>
<td><?php echo $row["rvasp_c"]?></td>
</tr>
<tr>
<td>20EC3L01</td>
<td>EDC LAB</td>
<td><?php echo $row["edclab_g"]?></td>
<td><?php echo $row["edclab_c"]?></td>
</tr>
<tr>
<td>20EC3L02</td>
<td>SIGNALS AND SYSTEMS LAB	</td>
<td><?php echo $row["saslab_g"]?></td>
<td><?php echo $row["saslab_c"]?></td>
</tr>
<tr>
<td>20CS3L03</td>
<td>DCLD LAB</td>
<td><?php echo $row["dcldlab_g"]?></td>
<td><?php echo $row["dcldlab_c"]?></td>
</tr>
<tr>
<td>20CS3C01</td>
<td>SOC(DATA PRE)</td>
<td><?php echo $row["soc_dpp_g"]?></td>
<td><?php echo $row["soc_dpp_g"]?></td>
</tr>
<tr>
<td>20SH3N01</td>
<td>ESSENCE OF INDIAN TRADITIONAL KNOWLEDGE</td>
<td><?php echo $row["eitk"]?></td>
</tr>
<tr>
<tr>
<td>20EC3N01</td>
<td>LIFE SKILLS III</td>
<td><?php echo $row["ls3"]?></td>
</tr>
<tr>

</tr>
<tr>
</tr>
<tr>
<td></td>
<td>Pass/Fail</td>
<td><?php echo $row["res"]?></td>
</tr>
<tr>
<td></td>
<td>SGPA</td>
<td><?php echo $row["sgpa"]?></td>
</tr>



 <?php   
} 
}
     }
elseif(strpos($rno,"1A61")!==false && substr($rno,0,2)=="21"){

  
  $query = "SELECT * FROM `21results_aim` where rollno='$rno'";
  
  $result = $conn->query($query);
  if ($result->num_rows > 0) 
    {

        while($row = $result->fetch_assoc())
        {
?>

<table id="t1">
<tr>
<th>HallTicketNo</th>
<td><?php echo $row["rollno"]?></td>
</tr>
<tr>
<th>Name</th>
<td><?php echo $row["name"]?></td>
</tr>
</table>
<br>
<table id="t2">
<tr>
<th>Subject Code</th>
<th>Subject</th>
<th>Grade</th>
<th>Credits</th>
</tr>
<tr>
<td>20SH3T01</td>
<td>MATHEMATICS III</td>
<td><?php echo $row["m3_g"]?></td>
<td><?php echo $row["m3_c"]?></td>
</tr>
<tr>
<td>20AM3T01</td>
<td>MATHEMATICAL FOUNDATION OF COMPUTER SCIENCE</td>
<td><?php echo $row["mfcs_g"]?></td>
<td><?php echo $row["mfcs_c"]?></td>
</tr>
<tr>
<td>20AM3T02</td>
<td>DATA STRUCTURES</td>
<td><?php echo $row["ds_g"]?></td>
<td><?php echo $row["ds_c"]?></td>
</tr>
<tr>
<td>20AM3T03</td>
<td>JAVA PROGRAMMING</td>
<td><?php echo $row["jp_g"]?></td>
<td><?php echo $row["jp_c"]?></td>
</tr>
<tr>
<td>20AM3T04</td>
<td>SOFTWARE ENGINEERING</td>
<td><?php echo $row["se_g"]?></td>
<td><?php echo $row["se_c"]?></td>
</tr>
<tr>
<td>20AM3L01</td>
<td>DATA STRUCTURES LAB</td>
<td><?php echo $row["dslab_g"]?></td>
<td><?php echo $row["dslab_c"]?></td>
</tr>
<tr>
<td>20AM3L02</td>
<td>JAVA PROGRAMMING LAB</td>
<td><?php echo $row["jplab_g"]?></td>
<td><?php echo $row["jplab_c"]?></td>
</tr>
<tr>
<td>20AM3L03</td>
<td>SOFTWARE ENGINEERING LAB</td>
<td><?php echo $row["selab_g"]?></td>
<td><?php echo $row["selab_c"]?></td>
</tr>
<tr>
<td>20AM3C01</td>
<td>SOC(ADVANCED PYTHON PROGRAMMIN)</td>
<td><?php echo $row["soc_ap_g"]?></td>
<td><?php echo $row["soc_ap_c"]?></td>
</tr>
<tr>
<td>20AM3N01</td>
<td>LIFE SKILLS III</td>
<td><?php echo $row["eitk"]?></td>
</tr>
<tr>
<td>20SH3N01</td>
<td>ESSENCE OF INDIAN TRADITIONAL KNOWLEDGE</td>
<td><?php echo $row["ls3"]?></td>
</tr>
<tr>
</tr>
<tr>
</tr>
<tr>
<td></td>
<td>Pass/Fail</td>
<td><?php echo $row["res"]?></td>
</tr>
<tr>
<td></td>
<td>SGPA</td>
<td><?php echo $row["sgpa"]?></td>
</tr>

 <?php   
} 
}
     }
elseif(strpos($rno,"1A54")!==false && substr($rno,0,2)=="21"){

 
  $query = "SELECT * FROM `21results_aid` where rollno='$rno'";
  
  $result = $conn->query($query);
  if ($result->num_rows > 0) 
    {

        while($row = $result->fetch_assoc())
        {
?>

<table id="t1">
<tr>
<th>HallTicketNo</th>
<td><?php echo $row["rollno"]?></td>
</tr>
<tr>
<th>Name</th>
<td><?php echo $row["name"]?></td>
</tr>
</table>
<br>
<table id="t2">
<tr>
<th>Subject Code</th>
<th>Subject</th>
<th>Grade</th>
<th>Credits</th>
</tr>
<tr>
<td>20SH3T01</td>
<td>MATHEMATICS III</td>
<td><?php echo $row["m3_g"]?></td>
<td><?php echo $row["m3_c"]?></td>
</tr>
<tr>
<td>20AD3T01</td>
<td>MATHEMATICAL FOUNDATIONS OF COMPYUTER SCIENCE</td>
<td><?php echo $row["mfsc_g"]?></td>
<td><?php echo $row["mfcs_c"]?></td>
</tr>
<tr>
<td>20AD3T02</td>
<td>DATA STRUCTURES</td>
<td><?php echo $row["ds_g"]?></td>
<td><?php echo $row["ds_c"]?></td>
</tr>
<tr>
<td>20AD3T03</td>
<td>JAVA PROGRAMMING</td>
<td><?php echo $row["jp_g"]?></td>
<td><?php echo $row["jp_c"]?></td>
</tr>
<tr>
<td>20AD3T04</td>
<td>DATABASE MANAGEMENT SYSTEMS</td>
<td><?php echo $row["dbms_g"]?></td>
<td><?php echo $row["dbms_c"]?></td>
</tr>
<tr>
<td>20AD3L01</td>
<td>DATA STRUCTURES LAB</td>
<td><?php echo $row["dslab_g"]?></td>
<td><?php echo $row["dslab_c"]?></td>
</tr>
<tr>
<td>20AD3L02</td>
<td>JAVA PROGRAMMING LAB</td>
<td><?php echo $row["jplab_g"]?></td>
<td><?php echo $row["jplab_c"]?></td>
</tr>
<tr>
<td>20AD3L03</td>
<td>DBMS LAB</td>
<td><?php echo $row["dbmslab_g"]?></td>
<td><?php echo $row["dbmslab_c"]?></td>
</tr>
<tr>
<td>20AD3C01</td>
<td>SOC(ADVANCED PYTHON PROGRAMMING)</td>
<td><?php echo $row["soc_ap_g"]?></td>
<td><?php echo $row["soc_ap_c"]?></td>
</tr>
<tr>
<td>20SH3N01</td>
<td>ESSENCE OF INDIAN TRADITIONAL KNOWLEDGE</td>
<td><?php echo $row["eitk"]?></td>
</tr>
<tr>
</tr>
<tr>
<td>20AD3N01</td>
<td>LIFE SKILLS III</td>
<td><?php echo $row["ls3"]?></td>
</tr>
<tr>
</tr>

<tr>
</tr>
<tr>
<td></td>
<td>Pass/Fail</td>
<td><?php echo $row["res"]?></td>
</tr>
<tr>
<td></td>
<td>SGPA</td>
<td><?php echo $row["sgpa"]?></td>
</tr>


 <?php   
} 
}
     }
elseif(strpos($rno,"1A01")!==false && substr($rno,0,2)=="21"){

  
  $query = "SELECT * FROM `21results_civil` where rollno='$rno'";
  
  $result = $conn->query($query);
  if ($result->num_rows > 0) 
    {

        while($row = $result->fetch_assoc())
        {
?>

<table id="t1">
<tr>
<th>HallTicketNo</th>
<td><?php echo $row["rollno"]?></td>
</tr>
<tr>
<th>Name</th>
<td><?php echo $row["name"]?></td>
</tr>
</table>
<br>
<table id="t2">
<tr>
<th>Subject Code</th>
<th>Subject</th>
<th>Grade</th>
<th>Credits</th>
</tr>
<tr>
<td>20SH2T01</td>
<td>MATHEMATICS III</td>
<td><?php echo $row["m3_g"]?></td>
<td><?php echo $row["m3_c"]?></td>
</tr>
<tr>
<td>20CE2T01</td>
<td>STRENGTH OF MATERIALS</td>
<td><?php echo $row["som_g"]?></td>
<td><?php echo $row["som_c"]?></td>
</tr>
<tr>
<td>20CE2T02</td>
<td>FLUID MECHANICS</td>
<td><?php echo $row["fm_g"]?></td>
<td><?php echo $row["fm_c"]?></td>
</tr>
<tr>
<td>20CE3T03</td>
<td>SURVEYING</td>
<td><?php echo $row["sur_g"]?></td>
<td><?php echo $row["sur_c"]?></td>
</tr>
<tr>
<td>20CE3T04</td>
<td>CONCRETE TECHNOLOGY</td>
<td><?php echo $row["ct_g"]?></td>
<td><?php echo $row["ct_c"]?></td>
</tr>
<tr>
<td>20CE2T01</td>
<td>STRENGTH OF MATERIALS LAB</td>
<td><?php echo $row["somlab_g"]?></td>
<td><?php echo $row["somlab_c"]?></td>
</tr>

<td>20CE3T03</td>
<td>SURVEYING LAB</td>
<td><?php echo $row["surlab_g"]?></td>
<td><?php echo $row["surlab_c"]?></td>
</tr>

<tr>
<td>20CE3L01</td>
<td>CONCRETE TECHNOLOGY LAB</td>
<td><?php echo $row["ctlab_g"]?></td>
<td><?php echo $row["ctlab_c"]?></td>
</tr>
<tr>
<td>20CE3L02</td>
<td> SOC(ADVANCE AUTO CAD)</td>
<td><?php echo $row["soc_aac_g"]?></td>
<td><?php echo $row["soc_aac_c"]?></td>
</tr>
<tr>
<td>20CE3L03</td>
<td>ESSENCE OF INDIAN TRADITIONAL KNOWLEDGE</td>
<td><?php echo $row["eitk"]?></td>
</tr>
<tr>
<td>20CS3C01</td>
<td>INDIAN CONSTITUTION</td>
<td><?php echo $row["eitk"]?></td>
<td>3</td>
</tr>
<tr>
<td>20SH3N01</td>
<td>LIFE SKILLS III</td>
<td><?php echo $row["ls3"]?></td>
</tr>
<tr>
</tr>
<tr>
</tr>
<tr>
<td></td>
<td>Pass/Fail</td>
<td><?php echo $row["res"]?></td>
</tr>
<tr>
<td></td>
<td>SGPA</td>
<td><?php echo $row["sgpa"]?></td>
</tr>

 <?php   
} 
}
     }
elseif(strpos($rno,"1A47")!==false && substr($rno,0,2)=="21"){

  $query = "SELECT * FROM `21results_cic` where rollno='$rno'";
  
  $result = $conn->query($query);
  if ($result->num_rows > 0) 
    {

        while($row = $result->fetch_assoc())
        {
?>

<table id="t1">
<tr>
<th>HallTicketNo</th>
<td><?php echo $row["rollno"]?></td>
</tr>
<tr>
<th>Name</th>
<td><?php echo $row["name"]?></td>
</tr>
</table>
<br>
<table id="t2">
<tr>
<th>Subject Code</th>
<th>Subject</th>
<th>Grade</th>
<th>Credits</th>
</tr>
<tr>
<td>20SH3T01</td>
<td>MATHEMATICS III</td>
<td><?php echo $row["m3_g"]?></td>
<td><?php echo $row["m3_c"]?></td>
</tr>
<tr>
<td>20CC3T01</td>
<td>DATA STRUCTURES</td>
<td><?php echo $row["ds_g"]?></td>
<td><?php echo $row["ds_c"]?></td>
</tr>
<tr>
<td>20CC3T02</td>
<td>JAVA PROGRAMMING</td>
<td><?php echo $row["jp_g"]?></td>
<td><?php echo $row["jp_c"]?></td>
</tr>
<tr>
<td>20CC3T03</td>
<td>MATHEMATICAL FOUNDATIONS OF COMPYUTER SCIENCE</td>
<td><?php echo $row["mfcs_g"]?></td>
<td><?php echo $row["mfcs_c"]?></td>
</tr>
<tr>
<td>20CC3T04</td>
<td>SOFTWARE ENGINEERING</td>
<td><?php echo $row["se_g"]?></td>
<td><?php echo $row["se_c"]?></td>
</tr>
<tr>
<td>20CC3L01</td>
<td>DATA STRUCTURES LAB</td>
<td><?php echo $row["dslab_g"]?></td>
<td><?php echo $row["dslab_c"]?></td>
</tr>
<tr>
<td>20CC3L02</td>
<td>JAVA PROGRAMMING LAB</td>
<td><?php echo $row["jplab_g"]?></td>
<td><?php echo $row["jplab_c"]?></td>
</tr>
<tr>
<td>20CC3L03</td>
<td>UML LAB</td>
<td><?php echo $row["umllab_g"]?></td>
<td><?php echo $row["umllab_c"]?></td>
</tr>
<tr>
<td>20CC3C01</td>
<td>SOC(ADVANCED PYTHON PROGRAMMING )</td>
<td><?php echo $row["soc_ap_g"]?></td>
<td><?php echo $row["soc_ap_c"]?></td>
</tr>
<tr>
<td>20SH3N01</td>
<td>ESSENCE OF INDIAN TRADITIONAL KNOWLEDGE</td>
<td><?php echo $row["eitk"]?></td>
</tr>
<tr>
<td>20SH3N01</td>
<td>LIFE SKILLS III</td>
<td><?php echo $row["ls3"]?></td>
</tr>
<tr>
</tr>
<tr>
</tr>
<tr>
<td></td>
<td>Pass/Fail</td>
<td><?php echo $row["res"]?></td>
</tr>
<tr>
<td></td>
<td>SGPA</td>
<td><?php echo $row["sgpa"]?></td>
</tr>



 <?php   
} 
}
     }
elseif(strpos($rno,"1A42")!==false && substr($rno,0,2)=="21"){

  $rno=strtoupper($_POST['rollno']);
  $query = "SELECT * FROM `21results_csm` where rollno='$rno'";
  
  $result = $conn->query($query);
  if ($result->num_rows > 0) 
    {

        while($row = $result->fetch_assoc())
        {
?>

<table id="t1">
<tr>
<th>HallTicketNo</th>
<td><?php echo $row["rollno"]?></td>
</tr>
<tr>
<th>Name</th>
<td><?php echo $row["name"]?></td>
</tr>
</table>
<br>
<table id="t2">
<tr>
<th>Subject Code</th>
<th>Subject</th>
<th>Grade</th>
<th>Credits</th>
</tr>
<tr>
<td>20SH3T01</td>
<td>MATHEMATICS III</td>
<td><?php echo $row["m3_g"]?></td>
<td><?php echo $row["m3_c"]?></td>
</tr>
<tr>
<td>20CM3T01</td>
<td>MATHEMATICAL FOUNDATIONS OF COMPUTER SCIENCE</td>
<td><?php echo $row["mfcs_g"]?></td>
<td><?php echo $row["mfcs_c"]?></td>
</tr>
<tr>
<td>20CM3T02</td>
<td>DATA STTRUCTURES</td>
<td><?php echo $row["ds_g"]?></td>
<td><?php echo $row["ds_c"]?></td>
</tr>
<tr>
<td>20CM3T03</td>
<td>JAVA PROGRAMMING</td>
<td><?php echo $row["jp_g"]?></td>
<td><?php echo $row["jp_c"]?></td>
</tr>
<tr>
<td>20CM3T04</td>
<td>SOFTWARE ENGINEERING</td>
<td><?php echo $row["se_g"]?></td>
<td><?php echo $row["se_c"]?></td>
</tr>
<tr>
<td>20CM3L01</td>
<td>DATA STRUCTURES LAB</td>
<td><?php echo $row["dslab_g"]?></td>
<td><?php echo $row["dslab_c"]?></td>
</tr>
<tr>
<td>20CM3L02</td>
<td>JAVA PROGRAMMING LAB</td>
<td><?php echo $row["jplab_g"]?></td>
<td><?php echo $row["jplab_c"]?></td>
</tr>
<tr>
<td>20CM3L03</td>
<td>SOFTWARE ENGINEERING LAB</td>
<td><?php echo $row["selab_g"]?></td>
<td><?php echo $row["selab_c"]?></td>
</tr>
<tr>
<td>20CM3C01</td>
<td>SOC(ADVANCED PYTHON PROGRAMMING)</td>
<td><?php echo $row["soc_ap_g"]?></td>
<td><?php echo $row["soc_ap_g"]?></td>
</tr>
<tr>
<td>20CM3C01</td>
<td>ESSENCE OF INDIAN TRADITIONAL KNOWLEDGE</td>
<td><?php echo $row["eitk"]?></td>
<td>3</td>
</tr>
<tr>
<td>20SH3N01</td>
<td>LIFE SKILLS III</td>
<td><?php echo $row["ls3"]?></td>
</tr>
<tr>
</tr>
<tr>
</tr>
<tr>
<td></td>
<td>Pass/Fail</td>
<td><?php echo $row["res"]?></td>
</tr>
<tr>
<td></td>
<td>SGPA</td>
<td><?php echo $row["sgpa"]?></td>
</tr>


 <?php   
} 
}
     }
elseif(strpos($rno,"1A49")!==false && substr($rno,0,2)=="21"){

  $rno=strtoupper($_POST['rollno']);
  $query = "SELECT * FROM `21results_cso` where rollno='$rno'";
  
  $result = $conn->query($query);
  if ($result->num_rows > 0) 
    {

        while($row = $result->fetch_assoc())
        {
?>

<table id="t1">
<tr>
<th>HallTicketNo</th>
<td><?php echo $row["rollno"]?></td>
</tr>
<tr>
<th>Name</th>
<td><?php echo $row["name"]?></td>
</tr>
</table>
<br>
<table id="t2">
<tr>
<th>Subject Code</th>
<th>Subject</th>
<th>Grade</th>
<th>Credits</th>
</tr>
<tr>
<td>20SH3T01</td>
<td>MATHEMATICS III</td>
<td><?php echo $row["m3_g"]?></td>
<td><?php echo $row["m3_c"]?></td>
</tr>
<tr>
<td>20CO3T01</td>
<td>MATHEMATICAL FOUNDATIONS OF COMPUTER SCIENCE</td>
<td><?php echo $row["mfcs_g"]?></td>
<td><?php echo $row["mfcs_c"]?></td>
</tr>
<tr>
<td>20CO3T02</td>
<td>DATA STRUCTURES</td>
<td><?php echo $row["ds_g"]?></td>
<td><?php echo $row["ds_c"]?></td>
</tr>
<tr>
<td>20CO3T03</td>
<td>JAVA PROGRAMMING</td>
<td><?php echo $row["jp_g"]?></td>
<td><?php echo $row["jp_c"]?></td>
</tr>
<tr>
<td>20CO3T04</td>
<td>DATA COMMUNICATIONS & NETWORKING FOR IOT</td>
<td><?php echo $row["dcn_g"]?></td>
<td><?php echo $row["dcn_c"]?></td>
</tr>
<tr>
<td>20CO3L01</td>
<td>DATA STRUCTURES LAB</td>
<td><?php echo $row["dslab_g"]?></td>
<td><?php echo $row["dslab_c"]?></td>
</tr>
<tr>
<td>20CO3L02</td>
<td>JAVA PROGRAMMING LAB</td>
<td><?php echo $row["jplab_g"]?></td>
<td><?php echo $row["jplab_c"]?></td>
</tr>
<tr>
<td>20CO3L03</td>
<td>DCN FOR IOT LAB</td>
<td><?php echo $row["dcnlab_g"]?></td>
<td><?php echo $row["dcnlab_c"]?></td>
</tr>
<tr>
<td>20CO3C01</td>
<td>SOC(INTRODUCTION TO ELECTRONICS HARDWARE AND SOFTWARE)</td>
<td><?php echo $row["soc_ioehas_g"]?></td>
<td><?php echo $row["soc_ioehas_c"]?></td>
</tr>
<tr>
<td>20SH3N01</td>
<td>ESSENCE OF INDIAN TRADITIONAL KNOWLEDGE</td>
<td><?php echo $row["eitk"]?></td>
</tr>
<tr>
<td>20SH3N01</td>
<td>LIFE SKILLS III</td>
<td><?php echo $row["ls3"]?></td>
</tr>
<tr>
</tr>
<tr>
</tr>
<tr>
<td></td>
<td>Pass/Fail</td>
<td><?php echo $row["res"]?></td>
</tr>
<tr>
<td></td>
<td>SGPA</td>
<td><?php echo $row["sgpa"]?></td>
</tr>

 <?php   
} 
}
     }
elseif(strpos($rno,"1A02")!==false && substr($rno,0,2)=="21"){

  $rno=strtoupper($_POST['rollno']);
  $query = "SELECT * FROM `21results_eee` where rollno='$rno'";
  
  $result = $conn->query($query);
  if ($result->num_rows > 0) 
    {

        while($row = $result->fetch_assoc())
        {
?>

<table id="t1">
<tr>
<th>HallTicketNo</th>
<td><?php echo $row["rollno"]?></td>
</tr>
<tr>
<th>Name</th>
<td><?php echo $row["name"]?></td>
</tr>
</table>
<br>
<table id="t2">
<tr>
<th>Subject Code</th>
<th>Subject</th>
<th>Grade</th>
<th>Credits</th>
</tr>
<tr>
<td>20SH3T01</td>
<td>MATHEMATICS III</td>
<td><?php echo $row["m3_g"]?></td>
<td><?php echo $row["m3_c"]?></td>
</tr>
<tr>
<td>20CS3T01</td>
<td>DATA STRUCTURES</td>
<td><?php echo $row["ds_g"]?></td>
<td><?php echo $row["ds_c"]?></td>
</tr>
<tr>
<td>20EE3T02</td>
<td>ELECTRICAL MACHINES</td>
<td><?php echo $row["em_g"]?></td>
<td><?php echo $row["em_c"]?></td>
</tr>
<tr>
<td>20EE3T03</td>
<td>ELECTRICAL CIRCUIT ANALYSIS</td>
<td><?php echo $row["eca_g"]?></td>
<td><?php echo $row["eca_c"]?></td>
</tr>
<tr>
<td>20EE3T04</td>
<td>ELECTROMAGNETIC FEILDS</td>
<td><?php echo $row["ef_g"]?></td>
<td><?php echo $row["ef_c"]?></td>
</tr>
<tr>
<td>20EE3L01</td>
<td>DATA STRUCTURES LAB</td>
<td><?php echo $row["dslab_g"]?></td>
<td><?php echo $row["dslab_c"]?></td>
</tr>
<tr>
<td>20EE3L02</td>
<td>ELECTRICAL MACHINES LAB</td>
<td><?php echo $row["emlab_g"]?></td>
<td><?php echo $row["emlab_c"]?></td>
</tr>
<tr>
<td>20EE3L03</td>
<td>ELECTRICAL CIRCUIT ANALYSIS LAB</td>
<td><?php echo $row["ecalab_g"]?></td>
<td><?php echo $row["ecalab_c"]?></td>
</tr>
<tr>
<td>20EE3C01</td>
<td>SOC(FUNDAMENTAL OF INTERNET OF THINGS)</td>
<td><?php echo $row["soc_foiof_g"]?></td>
<td><?php echo $row["soc_foiof_g"]?></td>
</tr>
<tr>
<tr>
<td>20SH3N01</td>
<td>ESSENCE OF INDIAN TRADITIONAL KNOWLEDGE</td>
<td><?php echo $row["eitk"]?></td>
</tr>
<tr>


<tr>
<td>20SH3N01</td>
<td>LIFE SKILLS III</td>
<td><?php echo $row["ls3"]?></td>
</tr>
<tr>
</tr>
<tr>
</tr>
<tr>
<td></td>
<td>Pass/Fail</td>
<td><?php echo $row["res"]?></td>
</tr>
<tr>
<td></td>
<td>SGPA</td>
<td><?php echo $row["sgpa"]?></td>
</tr>

 <?php   
} 
}
     }
elseif(strpos($rno,"1A03")!==false && substr($rno,0,2)=="21"){

  
  $query = "SELECT * FROM `21results_mech` where rollno='$rno'";
  
  $result = $conn->query($query);
  if ($result->num_rows > 0) 
    {

        while($row = $result->fetch_assoc())
        {
?>

<table id="t1">
<tr>
<th>HallTicketNo</th>
<td><?php echo $row["rollno"]?></td>
</tr>
<tr>
<th>Name</th>
<td><?php echo $row["name"]?></td>
</tr>
</table>
<br>
<table id="t2">
<tr>
<th>Subject Code</th>
<th>Subject</th>
<th>Grade</th>
<th>Credits</th>
</tr>
<tr>
<td>20SH3T01</td>
<td>MATHEMATICS III</td>
<td><?php echo $row["m3_g"]?></td>
<td><?php echo $row["m3_c"]?></td>
</tr>
<tr>
<td>20ME3T01</td>
<td>MECHANICS OF SOLIDS</td>
<td><?php echo $row["mos_g"]?></td>
<td><?php echo $row["mos_c"]?></td>
</tr>
<tr>
<td>20ME3T02</td>
<td>KINEMATICS OF MACHINERY</td>
<td><?php echo $row["kom_g"]?></td>
<td><?php echo $row["kom_c"]?></td>
</tr>
<tr>
<td>20ME3T03</td>
<td>PRODUCTION TECHNOLOGY</td>
<td><?php echo $row["pt_g"]?></td>
<td><?php echo $row["pt_c"]?></td>
</tr>
<tr>
<td>20ME3T04</td>
<td>MACHINE DRAWING</td>
<td><?php echo $row["md_g"]?></td>
<td><?php echo $row["md_c"]?></td>
</tr>
<tr>
<td>20ME3L01</td>
<td>THERMO DYNAMICS</td>
<td><?php echo $row["td_g"]?></td>
<td><?php echo $row["td_c"]?></td>
</tr>
<tr>
<td>20ME3L02</td>
<td>PRODUCTION TECHNOLOGY LAB</td>
<td><?php echo $row["ptlab_g"]?></td>
<td><?php echo $row["ptlab_c"]?></td>
</tr>
<tr>
<td>20ME3L02</td>
<td>MATERIALS AND MECHANICS OF SOLIDS LAB</td>
<td><?php echo $row["mamoslab_g"]?></td>
<td><?php echo $row["mamoslab_c"]?></td>
</tr>
<tr>
<td>20ME3C01</td>
<td>SOC(CAAED WITH NX)</td>
<td><?php echo $row["soc_caaed_g"]?></td>
<td><?php echo $row["soc_caaed_c"]?></td>
</tr>
<tr>
<td>20SH3N01</td>
<td>ESSENCE OF INDIAN TRADITIONAL KNOWLEDGE</td>
<td><?php echo $row["eitk"]?></td>
<td>3</td>
</tr>
<tr>
<td>20ME3N01</td>
<td>LIFE SKILLS III</td>
<td><?php echo $row["ls3"]?></td>
</tr>
<tr>
</tr>
<tr>
</tr>
<tr>
<td></td>
<td>Pass/Fail</td>
<td><?php echo $row["res"]?></td>
</tr>
<tr>
<td></td>
<td>SGPA</td>
<td><?php echo $row["sgpa"]?></td>
</tr>



   <?php
}
}
   }else{
echo("Record not found......");
}
}
   $conn->close();
?>

  





</div>
</body>
</html>