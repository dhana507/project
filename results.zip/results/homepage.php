<html>
<head>
<title>Project</title>
<style>
#t1{
width:600px;
height:40px;
}
div{
width:1500px;
height:150px;
background-color:#ff6600;
}
tr:nth-child(even){
	background-color:#cccccc;
}
td{
padding:20px;
}
</style>
</head>
<body>
<div >
<h1 align="center">VASIREDDY VENKATADRI INSTITUTE OF TECHNOLOGY</h1>
<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAK8AAAB6CAMAAAD+v/PbAAABZVBMVEX////ofmrod1/76+nneWTxsaYAAAD5jXrofGj++/r99fPqjXzvpZn76OQnI2nnd2IkH2Dw8PD1ysKmpaXh4eEgHFrn5+dBLYDW1tbKyckiQoG3traura329vYWS4zR0NDBwMCcm5uGhYUlLmokN3USVJQCg8HtnpDmcFlubGxVUlNlY2MyLi9cWlp6eHglKF4SYqMBmdQAquJAPT5KR0gGcLAEeroCjsv53dgaFBY4xfB2R2ldP2vIbmbzvbTrlYYjHyDc6PC4zdulprSNnrWDt9KRxuC33e/M5vPr+f+jyt5ZkrZUoMVPhatuk7Ncd5tBWYEaTnyRrsZUZoY5QGxfX4AxMl+UlKYjlcQ2X5A0QXd9hKZubo8AQIkAAE28vcoMDEuRl8RQUH8AJHKylZpCUY5ycqpfYJeGhbpxY6NMR41UR5ilZGoiAE0wKYaJ1PIvFmqYWnoOAFy8dXNyVHZPNGqEUGMhnqvzAAAL/0lEQVR4nO2cj3fbRBLH17Gjs5yfihRViiRLq8RN9LMudoIFNBaFlkILhQLlKMdxpdfS0gK5A/r338yu5NixXOyjkXPv/H2vrb1azX40Ozs76z6bkIUWmoNE6d13P/xw3hTTyr7+3vs3bty4+cGtW/8DzNc/un3n49u3b35y98bN2++/p8yb59X68KNPP/vsl5ufvH/v0/uff/PF9vaX74nzZnqFbn382ZW7d+/eu//5F1e4tu9/Jc2baqJu3fnr11cePNh9sMuUIX+lzptrgpT7u3uAuZcpQ97+5t15gxVL+ts2g93JxJDRwV/o80Yr1PVvERdAm0yMOIuKi5glpDbzbbPZyoTI3MV//27ecAX6rt1E3FarDTqEP4yYAf/joTVvunG1D5uc9vDwCHR4yIgR+Mr3Dy/ekpMeHbaBl9FeRgEyEDd3Hv+w+/Thwz9rXtxafr3653qrjbgI+ybTZfRxq/n4yQ9Pnj6d3tAE3uWl2uvU0m97Oxz3zTevciFwu93c+eHp4ycP6tMa+ssk3lrldar2ADJDjvsGKAcGBz979vjZtfp0duol8oJ7B7iMmAE3d56BLiBvq/UA3Mtx38qAmYN/fP78+UXjrb+z02q3tpsA/MZbTJmDOe+lqe2UxfsCwqF9dLj7009Xc14AhoBofQu8P0/p3tJ4K5VHGL5XW9vbP91B3DutIwC+3G5eQj2f1kppvPXtZvvo8tHeNujGL7/c/Prk5Crwthjuz/+6cLyVF3uwne0C7ebm3Q8Ad/2kfXT18uGPjPfaxeOt7O0w5wLv97fu/Xt9ff3SCa435J3avWXyvvi2ucdwN3fvXee8rebhDvJO7d4SeevXvszCARz8ZJ3xHp1gOPz8YgYr5fm3/utOhru5uc508iN699H00VAqL3h4M+PluOvtvcOTS+u/TR8N5fIC8O/D7oUMsXMCuNPuFaXzAvDLK+sDXFDr9xdLs1kolRf35bd/33zEYR+tvzObc+fAW6nXf3358u13QG+/fFmZkXZm3qzILzTF2ut/0AMA68B8DQT/nFosUtHDzMRbX8nOUBtFNNC+Uu/zDquT7l5BCG5mddhikVb+NG+/2kCJB+PXNrYajR706LEea/vjzqmvio1eH9vhBagH7PV+Y6LEAhszxsPKFr9acPFAJKS3VNno8R5bY8u+vgKXjjk467LGeIuHZyqcpJl4a9lpulpAQ0hjv1bZOOafP/fGbq8h2vFGubz7VX557Ar6tcGeYo11aIzfD8/aY+E7xFup9PsroNNWZhqb+v0CgFnzw8Yxv9w76+CNBsQAOu8gD4gz99crJI+SEd46E/oi42UpJG/8s7y1ZT7djaXxdpEb7Dc4TX90PJz56mp9jPfURMb76pQ8Iy9bNHj5TGwdQBRUedY4qGYGRpNeDZZqj7OUyAtpqygg6ivVQdLIe2yN3lgDm8cbpfPmK646MtjGFoTJwJ88ZKr7wxaQJr+nTN48wYpbI9MNjb28YYlniNEkjVGSz0m5vAUJtr4Ka2wwem0/C5kRniGTpfKyUCWDtc60BCHbOH17kNkYCoga5MHq6eOVyHuaYE8DApPG8uk4+YobajqACejlVUe5vLVVnmB7p3zLw+GQbQ1keE1iUhZP35XKmydYcpz3YKl1pPjLVtygwML03BgUdSXzDhJsvnwwxa0OD5OXAqcpuDr0eGXz1rMEu9bPNggoZMT+cHcs1pgyohrmlLHHKYt3EBB5l62srh3S1khAYM5eO63xy+YdTDeL2dp+Y6xUzcdeY81wLCFkqPwpmzdPsA2eYLGuPVuMrWQrjr3D9CyObC8l8y4NJVh+zBkbJKuT+SKDHltDPUrnzddTLzvRjHfOB8ckVlsdDYfyeSs1vmUwiuWzlQJ/omwXhCt4Jhkp58rnzVfcMiS3anaKPPNE+cHpgB2qlwvuLpM3T7CsGFvbH+9b28/OnRuYnkfCYQ68bAmxgKj1ij5rQMN8TcKZ4jjPfHPkzQOih6ltq+jjqbxOXsPUtlwvuLlU3uwUTPbHxs17ZCuuenz2aDSXeMgTbKPgswiurCwSG2O79Tx4c+tAXPSxUSU7JHGdsTUP3kGCJdWJhX22J4/v1vOIhzzBFmcHFDvko47PmJoPbzbdYuFqY6ZXeI+xj/7mwstOQWT4mDOmAx4Q4x+tcrJqubwbq1uo1cn2633WY/x/D3j78UpR77Ofa7423kp9A/XKbXtCj+J23lr4XyOvhXcuWvCerxa856sF7/lqwXu+WvCerxa856sF7/lqMu/B0oXUBF7SqF5QTeBdaKGFFvpj6aZCiK2LhBj4RVbVcGRRNBwiGYYpq0SSTdmxHNkwZEeEq6Zhwg2SY6pEMfB+Rcavk8pEhY4acbBNdYgGt2omXnYkQkyQjNYd/DKyCsZM7GeaBtysmtosvIYgE+LC7aIQw1tKdUqsyCOKHzsp/CMEjk5iwdHl0CCa7zmO7ykWFRwSM16tG0tESomeuIZCvAQg7ZjIgm11HUIsGtqA6QgdB6iUDg5hC65OuzCqEBldKtqpMQuvGrpEdcFHhu/D324A/rCCmKgBJV0BeCl0cgVodLsaNhJNcAE8tl3+NVKaaITqRA/RgXESgnNjYgq26+DTRCGjCQPWNRSwLYUrXiKRJLZi19LCmb6gbNGuZhoQDl2G5go++NdDXldOdODtejK4k/nFlAIKkIKHlJ1sGp3UJB2IqyQKdOLZaUdXgDf10ZXEpjTAGEgjdA2l6EsNHgnGUUjqGV2Ys3CmeEAMjC3Nh5m1iGimiSyif70gBH5FcC2J+Rc7qlHOqwZB9k1+8LsJk6uHjmSRQLUE33SBN0mAU3UdKiBOgv6VqdLtDHg1knZwhFl5VS+kMHSXyi4GH5s7Fg9mJFjD8RBHCvCK+AiESHGc//IAFQR4qXdwWsGZqpAAb6L7CTxt13RD9ojIS10zgK6MNxZEkgYUbpoxHmBCYe0QKQTrCSWwxjuGBZOpRFTtpAgnqWDdsgyIRMWnkpSAe4nkRTmvEvkW+tdQVBKpPL5hvRlJLOI6xpmHpQULBAM+8YkNvBSdKsRK4lo64s8izYV7KUypRGNF9jF+Y2oprkzcSFP9wHclGkR+rGDXKMKVzfoOftmBYkbT4YpBXAxWh8Li1UgcqEhoRJAhfJgSA7kCj9g+GMN+EfazbW+m/LDQQv93+u9+IMEavW2WX2JRI5MoLixcUXaIHlPPcgPP80wiwyt4EciSjAlAdyX2VieR57n8p1O0gJqeKUJXL3CxwYQenmsZgRdBpoBGtIPpLsCt3sEekNh1T5YDeON4LN/SwKDslRPELmzzOqQRyZvEi9uA5qcK8BqqZ1q6JUHmgg3KDSVJDXwFXnUAT/eJZEMmtmBTs7hDpNDlyRh2LknifosFSbJooEkiiVJV0jTIuirLukqQgFdkE7KubEH1oxOD5VsqKJZEuzbshIYkKcALyd81X8WruClsYKajddkWDx6Ev1wfELwIZs7tIm+EWy9sakRws1v9VGSbsEqFwYyy/Y96WDoKetYisV1YcUPYeWVH8j0cpBsSo2Ozqo5TSJ6fWYHHjyeGCPOvqXcE0bCJnAiySESf8QZjvAovcsIONxeG+LcsKDTtdNwhXjnphGogZC1JGqbIazqRIMm6yp/XFzivmbLiOHWN0MTHhz96V5hcSDBe2XLS0LSRCrpmvPi4EeNl8eBhJSQP+5fz0lQZ8m/M/IvP4wnWqH9lye4KVFdTdn834byASVgBoHfQeBrwEHklrw5lDvhEE6He7gJvl/F2YRyf8UJ0Q/mOc8f8G+dzn+DG7LtQZA5+uojz4ow7WP4TMYvfgGhUJU6Y2JaLa9EGasarRlhgOqljxV1oD6MpeA0sy2hHU6hhuBIRO4w3hHG6yKv7rmNgSNrIKwqR43DXQbbQXU9hJeGAVwRe3zSh9OwYuqMNeHVMKiasOaindR3qPiKH1ICDU9fUjQjr0MB19DD+A15Jtolm4/imJBlURk+ZDsHjHJYoBl6BWpuy85ZhQ3TD8czIEoQsyybGijyIBwcGFm1Zxv5gDYo8XQYTkCtVHTthdxVvg0YNumloHQ+GaN6EG2wcT54lIy+00EKvUf8BtEnEONtyYHsAAAAASUVORK5CYII=" align="left" width="150px" height="150px" style="background-color:#ff6600"></div><br><br><br>
<h2>All Autonomous Results</h2>
<table>
<tr>
<th>Date</th>
<th>Semester</th>
<th>Link</th>
</tr>
<tr>

<td>13.07.2023</td>
<td id="t1" >I B.Tech I Semester (R20-2021 Admitted Batch) Regular Examinations, January 2023</td>
<td><a href="11res.php" name="link2"  value="II B.Tech I Semester (R20-2021 Admitted Batch) Regular Examinations, January 2023" >click here</a></td>

</tr>
<tr>
<td>24.05.2023</td>
<td id="t1">I B.Tech II Semester (R20-2021 Admitted Batch) Regular Examinations, January 2023</td>
<td><a href="12res1.php" name="link2" value="I B.Tech II Semester (R20-2021 Admitted Batch) Regular Examinations, January 2023">click here</a></td>

</tr>
<tr>
<td>24.05.2023</td>
<td id="t1">II B.Tech I Semester (R20-2021 Admitted Batch) Regular Examinations, January 2023</td>
<td><a href="21res.php"  name="link3" value="I B.Tech I Semester (R20-2021 Admitted Batch) Regular Examinations, January 2023">click here</a></td>
</tr>
<tr>
<td>24.05.2023</td>
<td id="t1">II B.Tech II Semester (R20-2021 Admitted Batch) Regular Examinations, January 2023</td>
<td><a href="22res.php"  name="link3" value="I B.Tech I Semester (R20-2021 Admitted Batch) Regular Examinations, January 2023">click here</a></td>
</tr>

<tr>
<td>24.05.2023</td>
<td id="t1">III B.Tech I Semester (R20-2021 Admitted Batch) Regular Examinations, January 2023</td>
<td><a href="31res.php"  name="link3" value="I B.Tech I Semester (R20-2021 Admitted Batch) Regular Examinations, January 2023">click here</a></td>
</tr>

<tr>
<td>24.05.2023</td>
<td id="t1">III B.Tech II Semester (R20-2021 Admitted Batch) Regular Examinations, January 2023</td>
<td><a href="32res.php"  name="link3" value="I B.Tech I Semester (R20-2021 Admitted Batch) Regular Examinations, January 2023">click here</a></td>
</tr>



</table>
</body>
</html>